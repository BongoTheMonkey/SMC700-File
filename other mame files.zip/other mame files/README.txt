How to have excitment with SNES games on Mame.
1. unzip this folder.
2. put it into the roms folder
3. HAVE FUN